echo "hello" > /tmp/hello.txt
